const express = require('express')
const { Group, UserGroup, sequelize } = require('../models')
const auth = require('../utils/auth')

const router = express.Router()

router.get('/', auth, async (req, res) => {
  try {
    const { page = 1, pageSize = 10, status } = req.query
    const where = {}
    if (status !== undefined) where.status = status

    const { count, rows } = await Group.findAndCountAll({
      where,
      limit: parseInt(pageSize),
      offset: (page - 1) * pageSize
    })

    for (const g of rows) {
      const memberCount = await UserGroup.count({ where: { group_id: g.id } })
      g.dataValues.memberCount = memberCount
    }

    res.json({ code: 0, data: { list: rows, total: count } })
  } catch (err) {
    res.json({ code: -1, message: err.message })
  }
})

router.get('/my', auth, async (req, res) => {
  try {
    const userGroups = await UserGroup.findAll({ where: { user_id: req.userId } })
    const groupIds = userGroups.map(ug => ug.group_id)

    if (groupIds.length === 0) {
      return res.json({ code: 0, data: [] })
    }

    const groups = await Group.findAll({ 
      where: { id: groupIds },
      order: [['id', 'ASC']]
    })

    const result = await Promise.all(groups.map(async g => {
      const memberCount = await UserGroup.count({ where: { group_id: g.id } })
      return {
        groupId: g.id,
        groupName: g.name,
        description: g.description,
        initCash: parseFloat(g.init_cash),
        currency: g.currency,
        memberCount
      }
    }))

    res.json({ code: 0, data: result })
  } catch (err) {
    res.json({ code: -1, message: err.message })
  }
})

router.get('/:id', auth, async (req, res) => {
  try {
    const group = await Group.findByPk(req.params.id)
    if (!group) {
      return res.json({ code: -1, message: '群组不存在' })
    }
    const memberCount = await UserGroup.count({ where: { group_id: group.id } })
    group.dataValues.memberCount = memberCount
    res.json({ code: 0, data: group })
  } catch (err) {
    res.json({ code: -1, message: err.message })
  }
})

router.post('/join', auth, async (req, res) => {
  try {
    const { group_id } = req.body
    if (!group_id) {
      return res.json({ code: -1, message: '参数不完整' })
    }

    const group = await Group.findByPk(group_id)
    if (!group) {
      return res.json({ code: -1, message: '群组不存在' })
    }

    const exist = await UserGroup.findOne({ where: { user_id: req.userId, group_id } })
    if (exist) {
      return res.json({ code: -1, message: '已在群组中' })
    }

    await UserGroup.create({ user_id: req.userId, group_id })

    res.json({ code: 0, message: 'success' })
  } catch (err) {
    res.json({ code: -1, message: err.message })
  }
})

router.post('/leave', auth, async (req, res) => {
  try {
    const { group_id } = req.body
    if (!group_id) {
      return res.json({ code: -1, message: '参数不完整' })
    }

    await UserGroup.destroy({ where: { user_id: req.userId, group_id } })

    res.json({ code: 0, message: 'success' })
  } catch (err) {
    res.json({ code: -1, message: err.message })
  }
})

router.get('/:groupId/ranking', auth, async (req, res) => {
  try {
    const { groupId } = req.params
    const members = await UserGroup.findAll({ where: { group_id: groupId } })

    const ranking = []
    for (const m of members) {
      ranking.push({
        userId: m.user_id,
        rank: 0
      })
    }

    ranking.sort((a, b) => b.totalAssets - a.totalAssets)
    for (let i = 0; i < ranking.length; i++) {
      ranking[i].rank = i + 1
    }

    res.json({ code: 0, data: ranking })
  } catch (err) {
    res.json({ code: -1, message: err.message })
  }
})

module.exports = router
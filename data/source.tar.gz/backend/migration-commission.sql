-- 佣金配置表
CREATE TABLE IF NOT EXISTS commission_configs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  market_type TINYINT NOT NULL,
  trade_type TINYINT NOT NULL,
  commission_rate DECIMAL(10,6) NOT NULL DEFAULT 0.005,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_market_trade (market_type, trade_type)
);

-- 交易记录表添加佣金字段
ALTER TABLE transactions 
ADD COLUMN IF NOT EXISTS commission DECIMAL(15,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS commission_rate DECIMAL(10,6) DEFAULT 0;

-- 初始化佣金配置数据
-- A股: 万分之5 (0.0005)
-- 港股: 千分之1 (0.001)
-- 美股: 千分之5 (0.005)
INSERT INTO commission_configs (market_type, trade_type, commission_rate) VALUES
(1, 1, 0.0005),
(1, 2, 0.0005),
(2, 1, 0.001),
(2, 2, 0.001),
(3, 1, 0.005),
(3, 2, 0.005)
ON DUPLICATE KEY UPDATE commission_rate = VALUES(commission_rate);
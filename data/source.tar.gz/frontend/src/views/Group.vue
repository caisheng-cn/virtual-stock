<template>
  <div class="group-container">
    <div class="header">
      <h2>{{ $t('group_page.title') }}</h2>
      <el-button @click="$router.push('/home')">{{ $t('common.back') }}</el-button>
    </div>

    <el-card>
      <template #header>
        <div class="card-header">
          <span>{{ $t('group_page.member_ranking') }}</span>
          <el-select v-model="currentGroup" :placeholder="$t('group_page.select_group')" @change="fetchRanking">
            <el-option v-for="g in groups" :key="g.groupId" :label="g.groupName" :value="g.groupId" />
          </el-select>
        </div>
      </template>

      <el-table :data="ranking" stripe>
        <el-table-column prop="rank" :label="$t('group_page.rank')" width="80">
          <template #default="{ row }">
            <el-tag :type="row.rank <= 3 ? 'danger' : ''">{{ row.rank }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="nickname" :label="$t('group_page.nickname')" />
        <el-table-column prop="totalAssets" :label="$t('group_page.total_assets')" width="120">
          <template #default="{ row }">{{ formatMoney(row.totalAssets) || '-' }}</template>
        </el-table-column>
        <el-table-column prop="profit" :label="$t('group_page.profit')" width="120">
          <template #default="{ row }">
            <span :class="row.profit >= 0 ? 'profit' : 'loss'">
              {{ row.profit >= 0 ? '+' : '' }}{{ formatMoney(row.profit) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="profitRate" :label="$t('group_page.profit_rate')" width="100">
          <template #default="{ row }">
            <span :class="row.profitRate >= 0 ? 'profit' : 'loss'">
              {{ row.profitRate >= 0 ? '+' : '' }}{{ row.profitRate?.toFixed(2) || '0.00' }}%
            </span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card style="margin-top: 20px;">
      <template #header>
        <span>{{ $t('group_page.member_trades') }}</span>
      </template>
      <el-table :data="memberTrades" stripe>
        <el-table-column prop="userId" :label="$t('group_page.user_id')" width="80" />
        <el-table-column prop="stockCode" :label="$t('group_page.stock_code')" width="100" />
        <el-table-column prop="stockName" :label="$t('group_page.stock_name')" />
        <el-table-column prop="tradeType" :label="$t('group_page.type')" width="80">
          <template #default="{ row }">{{ row.tradeType === 1 ? $t('trade_page.buy') : $t('trade_page.sell') }}</template>
        </el-table-column>
        <el-table-column prop="shares" :label="$t('group_page.shares')" width="80" />
        <el-table-column prop="price" :label="$t('group_page.price')" width="100">
          <template #default="{ row }">{{ formatMoney(row.price) || '-' }}</template>
        </el-table-column>
        <el-table-column prop="tradeDate" :label="$t('group_page.date')" width="100" />
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import { getMyGroups, getGroupRanking } from '@/api/group'
import { getGroupMemberTrades } from '@/api/group'

const { t } = useI18n()

const groups = ref([])
const currentGroup = ref(null)
const ranking = ref([])
const memberTrades = ref([])

const formatMoney = (value) => {
  if (!value && value !== 0) return '0.00'
  return value.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

onMounted(async () => {
  groups.value = await getMyGroups().then(r => r.data || [])
  if (groups.value.length > 0) {
    currentGroup.value = groups.value[0].groupId
    fetchRanking()
  }
})

const fetchRanking = async () => {
  if (!currentGroup.value) return
  try {
    const res = await getGroupRanking(currentGroup.value)
    ranking.value = res.data || []
  } catch (err) {
    ElMessage.error(err.message || t('group_page.fetch_failed'))
  }
}
</script>

<style scoped>
.group-container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background: white;
  border-radius: 8px;
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.profit {
  color: #f56c6c;
}

.loss {
  color: #67c23a;
}
</style>
